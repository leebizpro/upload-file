<?php
/**
 * Price update script from CSV file.
 *
 * CSV format (2 columns, with header row):
 *   SKU,Price
 *   10005,4.88
 *   ...
 *
 * Matching logic:
 *   - productcode found in dbp_products  -> update dbp_pricing (main price)
 *   - productcode found in dbp_adv_options -> update dbp_adv_options.option_price
 *   - not found in either               -> skip, log as not found
 *
 * Usage (run from vagrant root or scripts/ folder):
 *   php scripts/update_prices_from_csv.php scripts/price_update.csv
 *
 * Use --dry-run to preview changes without writing to DB:
 *   php scripts/update_prices_from_csv.php scripts/price_update.csv --dry-run
 */

set_time_limit(0);
ini_set('auto_detect_line_endings', '1');

require __DIR__ . '/../admin/auth.php';

// ─── Arguments ───────────────────────────────────────────────────────────────

$args    = array_slice($argv, 1);
$dryRun  = in_array('--dry-run', $args);
$csvFile = null;

foreach ($args as $arg) {
    if ($arg !== '--dry-run') {
        $csvFile = $arg;
        break;
    }
}

if (!$csvFile) {
    echo "Usage: php " . basename(__FILE__) . " <path/to/price_update.csv> [--dry-run]\n";
    exit(1);
}

if (!file_exists($csvFile)) {
    echo "ERROR: File not found: {$csvFile}\n";
    exit(1);
}

if ($dryRun) {
    echo "[DRY RUN] No changes will be written to the database.\n\n";
}

// ─── Counters ────────────────────────────────────────────────────────────────

$stats = [
    'total'           => 0,
    'updated_pricing' => 0,
    'updated_adv'     => 0,
    'not_found'       => 0,
    'skipped_header'  => 0,
];

$notFound = [];

// ─── Process CSV ─────────────────────────────────────────────────────────────

$handle = fopen($csvFile, 'r');
if (!$handle) {
    echo "ERROR: Cannot open file: {$csvFile}\n";
    exit(1);
}

$rowIndex = 0;

while (($row = fgetcsv($handle)) !== false) {
    $rowIndex++;

    // Skip empty lines
    if (empty($row) || (count($row) === 1 && trim($row[0]) === '')) {
        continue;
    }

    // Skip header row
    if ($rowIndex === 1 && !is_numeric(trim($row[0]))) {
        $stats['skipped_header']++;
        continue;
    }

    if (count($row) < 2) {
        echo "WARNING: Row {$rowIndex} has fewer than 2 columns, skipping.\n";
        continue;
    }

    $productcode = trim($row[0]);
    $price       = (float) trim($row[1]);

    if ($productcode === '') {
        echo "WARNING: Row {$rowIndex} has empty SKU, skipping.\n";
        continue;
    }

    $stats['total']++;

    // ── Check dbp_products first ──────────────────────────────────────────
    $productId = (int) db_query_builder()
        ->select('productid')
        ->from('products')
        ->andWhereList(['productcode' => $productcode])
        ->setMaxResults(1)
        ->fetchCell();

    if ($productId) {
        // Update main price in dbp_pricing
        echo "PRODUCT  [{$productcode}] productid={$productId} -> set price={$price}\n";

        if (!$dryRun) {
            db_query_builder()
                ->array2update('pricing', ['price' => $price])
                ->andWhereList([
                    'productid'   => $productId,
                    'quantity'    => 1,
                    'membership'  => '',
                    'price_until' => 0,
                    'variantid'   => 0,
                ])
                ->execute();
        }

        $stats['updated_pricing']++;
        continue;
    }

    // ── Check dbp_adv_options ─────────────────────────────────────────────
    $optionIds = db_query_builder()
        ->select('option_id')
        ->from('adv_options')
        ->andWhereList(['productcode' => $productcode])
        ->fetchColumn();

    if (!empty($optionIds)) {
        $optionIdList = implode(', ', array_map('intval', $optionIds));
        echo "OPTION   [{$productcode}] option_id(s)={$optionIdList} -> set option_price={$price}\n";

        if (!$dryRun) {
            db_query_builder()
                ->array2update('adv_options', ['option_price' => $price])
                ->andWhereList(['productcode' => $productcode])
                ->execute();
        }

        $stats['updated_adv']++;
        continue;
    }

    // ── Not found in either table ─────────────────────────────────────────
    echo "NOT FOUND [{$productcode}]\n";
    $notFound[]       = $productcode;
    $stats['not_found']++;
}

fclose($handle);

// ─── Summary ─────────────────────────────────────────────────────────────────

echo "\n";
echo "─────────────────────────────────────────\n";
echo ($dryRun ? "[DRY RUN] " : "") . "Done.\n";
echo "  Total rows processed : {$stats['total']}\n";
echo "  dbp_pricing updated  : {$stats['updated_pricing']}\n";
echo "  dbp_adv_options upd. : {$stats['updated_adv']}\n";
echo "  Not found (skipped)  : {$stats['not_found']}\n";
echo "─────────────────────────────────────────\n";

if (!empty($notFound)) {
    echo "\nSKUs not found in any table:\n";
    foreach ($notFound as $code) {
        echo "  {$code}\n";
    }
}
